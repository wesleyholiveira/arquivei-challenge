<?php

namespace Symfony\Component\Debug\Tests\Fixtures;

/**
 * @method string traitMethod()
 */
trait VirtualTrait
{
}
